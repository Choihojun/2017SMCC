/**
 * \file Cpu0_Main.c
 * \brief Main function definition for Cpu core 0 .
 *
 * \copyright Copyright (c) 2012 Infineon Technologies AG. All rights reserved.
 *
 *
 *
 *                                 IMPORTANT NOTICE
 *
 *
 * Infineon Technologies AG (Infineon) is supplying this file for use
 * exclusively with Infineon's microcontroller products. This file can be freely
 * distributed within development tools that are supporting such microcontroller
 * products.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 * INFINEON SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 */

#include "Tricore/Cpu/Std/Ifx_Types.h"
#include "Tricore/Cpu/Std/IfxCpu_Intrinsics.h"
#include "Tricore/Scu/Std/IfxScuWdt.h"
#include <Stm/Std/IfxStm.h>
#include <Port/Std/IfxPort.h>

#include "Test_Irq.h"
#include "Test_ModuleInit.h"
#include "Test_Pwm.h"
#include "Test_Uart.h"
#include "Test_Adc.h"
#include "LineCamera.h"
#include "Sensor.h"

#define CCW 1
#define CW  1

#define NORM_RPM
#define SCHOOL_RPM

volatile uint16 initStartCount = 0;
volatile uint32 cameraStartCount = 0;
volatile uint16 cameraStartTime = 100; //50ms

volatile uint32 updateCount = 0;
volatile uint32 updateTime = 2000; //1000ms

volatile int wall = 0;
void core0_main (void)
{
    __enable ();
    int i = 0;
    /*
     * !!WATCHDOG0 AND SAFETY WATCHDOG ARE DISABLED HERE!!
     * Enable the watchdog in the demo if it is required and also service the watchdog periodically
     * */
    IfxScuWdt_disableCpuWatchdog (IfxScuWdt_getCpuWatchdogPassword ());
    IfxScuWdt_disableSafetyWatchdog (IfxScuWdt_getSafetyWatchdogPassword ());

    Test_ModuleInit();
	 P13_OUT.B.P2 = 0;
	 P13_OUT.B.P1 = 0;
	 P13_OUT.B.P0 = 0;
	 Delay_us(1000000);

	 P13_OUT.B.P2 = 1;
	 P13_OUT.B.P1 = 1;
	 P13_OUT.B.P0 = 1;

	 Pwm_DcDutyAndDirectionUpdate(CCW, 17);

    while (1)
    {

    	/*
    	school_jon_check_fun();

    	if(school_jon_check==1)
    	{
    		motor_dir_pwm(20);
    	}
    	else
    	{
    		motor_dir_pwm(25);
    	}


    	//cross_jon_check_fun();
    	if(cross_jon_check == 1)
    	{
    		cnt++;
    		while(1)
    		{
    			motor_dir_pwm(25);
    			Pwm_ServoDutyUpdate(650);

    			if(cnt ==1)
    			{
    				Delay_ms(100);
    			}

    		}
    	}
    	*/

    	if(cameraStartCount > cameraStartTime * 20) //���� ī�޶� ���� �� ��ġ ����
    	{
			Line_data_cam();
			Data_nomalization();
			Line_edge_detect();
			Line_density_detect();
			cameraStartCount = 0;
			cal_line_vector();

			Position_MID();
			Pwm_ServoDutyUpdate(duty_servo);
    	}

    	if(updateCount > updateTime * 20) //����ȭ
    	{
    		is_car_status_update_available = 1;
    		updateCount = 0;
    	}

    	if(is_car_status_update_available)
    	{
    		car_status_update();
    	}
    	/*
    	if(school_zone_flag)
    	{
    		is_emergence();
			if(emergence_flag)
			{
				if(wall == 0)
				{
					Pwm_DcDutyAndDirectionUpdate(CCW, 15);
					Pwm_ServoDutyUpdate(STEER_LEFT);
					Delay_ms(4000);
					Pwm_ServoDutyUpdate(STEER_RIGHT);
					Delay_ms(2000);
					Pwm_ServoDutyUpdate(STEER_MID);
					emergence_flag = 0;
				}
				else
				{
					Pwm_DcDutyAndDirectionUpdate(CCW, 15);
					Pwm_ServoDutyUpdate(STEER_RIGHT);
					Delay_ms(4000);
					Pwm_ServoDutyUpdate(STEER_LEFT);
					Delay_ms(2000);
					Pwm_ServoDutyUpdate(STEER_MID);
					emergence_flag = 0;
				}
				wall ^= 1;
			}
    	}
    	*/

    	//infrared();
    	if(emergence_flag == 1)
    	{
    		Pwm_DcDutyAndDirectionUpdate(CCW, 0);
    	}
    	else
    	{
    		Pwm_DcDutyAndDirectionUpdate(CCW, 15);
    	}
    	P13_OUT.B.P3 = !school_zone_flag;
    	P13_OUT.B.P2 = !cross_line_flag;
    	P13_OUT.B.P1 = !emergence_flag;
    }
}

void SecondTimer_Initialization(void)
{
    volatile float       stm_freq;
    Ifx_STM             *stm = &MODULE_STM0;
    IfxStm_CompareConfig stmCompareConfig;

    /* suspend by debugger enabled */
    IfxStm_enableOcdsSuspend(stm);
    /* get current STM frequency : debug purpose only*/
    stm_freq = IfxScuCcu_getStmFrequency();
    /* constructor of configuration */
    IfxStm_initCompareConfig(&stmCompareConfig);
	stmCompareConfig.triggerPriority = ISR_PRIORITY_STM;
	stmCompareConfig.ticks = 100000000;
	stmCompareConfig.typeOfService = IfxSrc_Tos_cpu0;
    /* Now Compare functionality is initialized */
    IfxStm_initCompare(stm, &stmCompareConfig);

} // End of TaskScheduler_Initialization()

//*********************************************************************************************
// @Function	 	void UsrIsr_Stm_0(void)
// @Description   	STM0 Interrupt for system tick generation
// @Returnvalue		None
// @Parameters    	None
//*********************************************************************************************
IFX_INTERRUPT (SecondTimer_Isr, 0, ISR_PRIORITY_STM);

void SecondTimer_Isr(void)
{
    Ifx_STM *stm = &MODULE_STM0;
    IfxStm_updateCompare(stm, IfxStm_Comparator_0, IfxStm_getLower(stm) + 5000);
    //100000000	: 1s
    //10000000  : 100ms
    //100000	: 1ms
    //100		: 1us
    //1000		: 10us

    //50us * 20 = 1000us = 1ms

    cameraStartCount++;
  //  encoder_counter();
  //  encoder_time_count++;
    updateCount++;
    __enable();
}
