/*
 * LineCamera.h
 *
 *  Created on: 2017. 6. 15.
 *      Author: user
 */



#ifndef LINECAMERA_H_
#define LINECAMERA_H_

#include "IfxPort_reg.h"
#include "IfxPort.h"
#include "Test_Pwm.h"
#include "Test_ADC.h"
#include <Port/Std/IfxPort.h>
#include "Tricore/Cpu/Std/Ifx_Types.h"
#include "IfxPort_reg.h"
#include "IfxPort.h"

#include "Tricore/Cpu/Std/IfxCpu_Intrinsics.h"
#include "Tricore/Scu/Std/IfxScuWdt.h"
#include <Stm/Std/IfxStm.h>
#include <Port/Std/IfxPort.h>

#include "Test_Irq.h"

#define USE_NORM 1//1 : ��ֶ����� Ȱ��, 0 : ��ֶ����� ��Ȱ��

extern volatile int line_data[2][128];
extern volatile int norm_data[2][128];
extern volatile int left_line_position;
extern volatile int right_line_position;
extern volatile int recent_empty_line; //�ֱ� �� ����
extern volatile int line_density;
extern volatile int sub_line_density;
extern volatile int offset;
extern volatile int flag1;
extern volatile int flag2;
extern volatile int vect_flag1;
extern volatile int vect_flag2;



extern void Line_data_cam();
extern void Data_nomalization();
extern void Line_edge_detect();
extern void get_max_adc_value();
extern void get_min_adc_value();
extern void Line_density_detect();


#endif /* 0_SRC_0_APPSW_APP_INC_LINECAMERA_H_ */

